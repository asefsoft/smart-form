-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2019 at 09:39 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `filled_forms`
--

CREATE TABLE `filled_forms` (
  `id` int(10) UNSIGNED NOT NULL,
  `form_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `questions` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `filled_forms`
--

INSERT INTO `filled_forms` (`id`, `form_id`, `title`, `questions`, `created_at`, `updated_at`) VALUES
(1, 1, 'فرم استخدام', '[{\"questionType\":\"Text\",\"questionText\":\"\\u0646\\u0627\\u0645\",\"questionAnswer\":\"\\u0639\\u0644\\u06cc\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"Text\",\"questionText\":\"\\u0646\\u0627\\u0645 \\u062e\\u0627\\u0646\\u0648\\u0627\\u062f\\u06af\\u06cc\",\"questionAnswer\":\"\\u0627\\u062d\\u0645\\u062f\\u06cc\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0648\\u0636\\u0639\\u06cc\\u062a \\u0633\\u0631\\u0628\\u0627\\u0632\\u06cc\",\"questionItems\":[\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u06a9\\u0641\\u0627\\u0644\\u062a\",\"\\u06a9\\u0627\\u0631\\u062a \\u067e\\u0627\\u06cc\\u0627\\u0646 \\u062e\\u062f\\u0645\\u062a\",\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u067e\\u0632\\u0634\\u06a9\\u06cc\"],\"questionAnswer\":\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u067e\\u0632\\u0634\\u06a9\\u06cc\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiCheckbox\",\"questionText\":\"\\u062a\\u062e\\u0635\\u0635 \\u0647\\u0627\",\"questionItems\":[\"\\u0637\\u0631\\u0627\\u062d\\u06cc \\u0648\\u0628\",\"\\u0628\\u0631\\u0646\\u0627\\u0645\\u0647 \\u0646\\u0648\\u06cc\\u0633\\u06cc PHP\",\"\\u062c\\u0627\\u0648\\u0627\",\"\\u0644\\u06cc\\u0646\\u0648\\u06a9\\u0633\",\"\\u0634\\u0628\\u06a9\\u0647\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\",\"\\u0628\\u0631\\u0646\\u0627\\u0645\\u0647 \\u0646\\u0648\\u06cc\\u0633\\u06cc PHP\",\"\\u0644\\u06cc\\u0646\\u0648\\u06a9\\u0633\"]},{\"questionType\":\"TextLarge\",\"questionText\":\"\\u062a\\u0648\\u0636\\u06cc\\u062d\\u0627\\u062a \\u0628\\u06cc\\u0634\\u062a\\u0631\",\"questionAnswer\":\"\\u0686\\u0647\\u0627\\u0631 \\u0633\\u0627\\u0644 \\u0633\\u0627\\u0628\\u0642\\u0647 \\u06a9\\u0627\\u0631\",\"questionAnswerCheckbox\":[\"\"]}]', '2016-10-21 17:53:59', '2016-10-21 17:53:59'),
(2, 2, 'فرم نظرسنجی', '[{\"questionType\":\"MultiOption\",\"questionText\":\"\\u06a9\\u06cc\\u0641\\u06cc\\u062a \\u063a\\u0630\\u0627\",\"questionItems\":[\"\\u062e\\u0648\\u0628\",\"\\u0645\\u062a\\u0648\\u0633\\u0637\",\"\\u0628\\u062f\"],\"questionAnswer\":\"\\u0645\\u062a\\u0648\\u0633\\u0637\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0632\\u0645\\u0627\\u0646 \\u0622\\u0645\\u0627\\u062f\\u0647 \\u0633\\u0627\\u0632\\u06cc \\u063a\\u0630\\u0627\",\"questionItems\":[\"\\u062e\\u0648\\u0628 \",\"\\u0645\\u062a\\u0648\\u0633\\u0637\",\"\\u0628\\u062f\"],\"questionAnswer\":\"\\u0645\\u062a\\u0648\\u0633\\u0637\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0628\\u0631\\u062e\\u0648\\u0631\\u062f \\u06a9\\u0627\\u0631\\u06a9\\u0646\\u0627\\u0646\",\"questionItems\":[\"\\u062e\\u0648\\u0628\",\"\\u0645\\u062a\\u0648\\u0633\\u0637\",\"\\u0628\\u062f\"],\"questionAnswer\":\"\\u062e\\u0648\\u0628\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiCheckbox\",\"questionText\":\"\\u0648\\u06cc\\u0698\\u06af\\u06cc \\u0647\\u0627\\u06cc \\u0628\\u0627\\u0631\\u0632 \\u0648 \\u0645\\u062b\\u0628\\u062a \\u0627\\u0632 \\u0646\\u0638\\u0631 \\u0634\\u0645\\u0627\",\"questionItems\":[\"\\u0645\\u0646\\u0638\\u0631\\u0647 \\u0628\\u06cc\\u0631\\u0648\\u0646\\u06cc\",\"\\u0622\\u0647\\u0646\\u06af \\u067e\\u062e\\u0634 \\u0634\\u062f\\u0647\",\"\\u0646\\u0645\\u0627\\u06cc \\u062f\\u0627\\u062e\\u0644\\u06cc\",\"\\u062a\\u0646\\u0648\\u0639 \\u063a\\u0630\\u0627 \\u0647\\u0627\",\"\\u0628\\u0631\\u062e\\u0648\\u0631\\u062f \\u06a9\\u0627\\u0631\\u06a9\\u0646\\u0627\\u0646\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\",\"\\u0622\\u0647\\u0646\\u06af \\u067e\\u062e\\u0634 \\u0634\\u062f\\u0647\",\"\\u062a\\u0646\\u0648\\u0639 \\u063a\\u0630\\u0627 \\u0647\\u0627\"]},{\"questionType\":\"TextLarge\",\"questionText\":\"\\u0646\\u0638\\u0631\\u0627\\u062a \\u0648 \\u067e\\u06cc\\u0634\\u0646\\u0647\\u0627\\u062f\\u0627\\u062a \\u062f\\u06cc\\u06af\\u0631\",\"questionAnswer\":\"\\u0628\\u0633\\u06cc\\u0627\\u0631 \\u062e\\u0648\\u0628\",\"questionAnswerCheckbox\":[\"\"]}]', '2016-10-21 18:00:08', '2016-10-21 18:00:08'),
(3, 2, 'فرم نظرسنجی', '[{\"questionType\":\"MultiOption\",\"questionText\":\"\\u06a9\\u06cc\\u0641\\u06cc\\u062a \\u063a\\u0630\\u0627\",\"questionItems\":[\"\\u062e\\u0648\\u0628\",\"\\u0645\\u062a\\u0648\\u0633\\u0637\",\"\\u0628\\u062f\"],\"questionAnswer\":\"\\u062e\\u0648\\u0628\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0632\\u0645\\u0627\\u0646 \\u0622\\u0645\\u0627\\u062f\\u0647 \\u0633\\u0627\\u0632\\u06cc \\u063a\\u0630\\u0627\",\"questionItems\":[\"\\u062e\\u0648\\u0628 \",\"\\u0645\\u062a\\u0648\\u0633\\u0637\",\"\\u0628\\u062f\"],\"questionAnswer\":\"\\u062e\\u0648\\u0628 \",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0628\\u0631\\u062e\\u0648\\u0631\\u062f \\u06a9\\u0627\\u0631\\u06a9\\u0646\\u0627\\u0646\",\"questionItems\":[\"\\u062e\\u0648\\u0628\",\"\\u0645\\u062a\\u0648\\u0633\\u0637\",\"\\u0628\\u062f\"],\"questionAnswer\":\"\\u0645\\u062a\\u0648\\u0633\\u0637\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiCheckbox\",\"questionText\":\"\\u0648\\u06cc\\u0698\\u06af\\u06cc \\u0647\\u0627\\u06cc \\u0628\\u0627\\u0631\\u0632 \\u0648 \\u0645\\u062b\\u0628\\u062a \\u0627\\u0632 \\u0646\\u0638\\u0631 \\u0634\\u0645\\u0627\",\"questionItems\":[\"\\u0645\\u0646\\u0638\\u0631\\u0647 \\u0628\\u06cc\\u0631\\u0648\\u0646\\u06cc\",\"\\u0622\\u0647\\u0646\\u06af \\u067e\\u062e\\u0634 \\u0634\\u062f\\u0647\",\"\\u0646\\u0645\\u0627\\u06cc \\u062f\\u0627\\u062e\\u0644\\u06cc\",\"\\u062a\\u0646\\u0648\\u0639 \\u063a\\u0630\\u0627 \\u0647\\u0627\",\"\\u0628\\u0631\\u062e\\u0648\\u0631\\u062f \\u06a9\\u0627\\u0631\\u06a9\\u0646\\u0627\\u0646\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\",\"\\u0622\\u0647\\u0646\\u06af \\u067e\\u062e\\u0634 \\u0634\\u062f\\u0647\",\"\\u0645\\u0646\\u0638\\u0631\\u0647 \\u0628\\u06cc\\u0631\\u0648\\u0646\\u06cc\"]},{\"questionType\":\"TextLarge\",\"questionText\":\"\\u0646\\u0638\\u0631\\u0627\\u062a \\u0648 \\u067e\\u06cc\\u0634\\u0646\\u0647\\u0627\\u062f\\u0627\\u062a \\u062f\\u06cc\\u06af\\u0631\",\"questionAnswer\":\"\\u0645\\u062a\\u0634\\u06a9\\u0631\\u0645\",\"questionAnswerCheckbox\":[\"\"]}]', '2016-10-21 18:00:26', '2016-10-21 18:00:26'),
(4, 1, 'فرم استخدام', '[{\"questionType\":\"Text\",\"questionText\":\"\\u0646\\u0627\\u0645\",\"questionAnswer\":\"\\u0631\\u0636\\u0627\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"Text\",\"questionText\":\"\\u0646\\u0627\\u0645 \\u062e\\u0627\\u0646\\u0648\\u0627\\u062f\\u06af\\u06cc\",\"questionAnswer\":\"\\u0628\\u0647\\u0645\\u0646\\u06cc\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0648\\u0636\\u0639\\u06cc\\u062a \\u0633\\u0631\\u0628\\u0627\\u0632\\u06cc\",\"questionItems\":[\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u06a9\\u0641\\u0627\\u0644\\u062a\",\"\\u06a9\\u0627\\u0631\\u062a \\u067e\\u0627\\u06cc\\u0627\\u0646 \\u062e\\u062f\\u0645\\u062a\",\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u067e\\u0632\\u0634\\u06a9\\u06cc\"],\"questionAnswer\":\"\\u06a9\\u0627\\u0631\\u062a \\u067e\\u0627\\u06cc\\u0627\\u0646 \\u062e\\u062f\\u0645\\u062a\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiCheckbox\",\"questionText\":\"\\u062a\\u062e\\u0635\\u0635 \\u0647\\u0627\",\"questionItems\":[\"\\u0637\\u0631\\u0627\\u062d\\u06cc \\u0648\\u0628\",\"\\u0628\\u0631\\u0646\\u0627\\u0645\\u0647 \\u0646\\u0648\\u06cc\\u0633\\u06cc PHP\",\"\\u062c\\u0627\\u0648\\u0627\",\"\\u0644\\u06cc\\u0646\\u0648\\u06a9\\u0633\",\"\\u0634\\u0628\\u06a9\\u0647\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\",\"\\u0637\\u0631\\u0627\\u062d\\u06cc \\u0648\\u0628\",\"\\u0644\\u06cc\\u0646\\u0648\\u06a9\\u0633\",\"\\u0634\\u0628\\u06a9\\u0647\"]},{\"questionType\":\"TextLarge\",\"questionText\":\"\\u062a\\u0648\\u0636\\u06cc\\u062d\\u0627\\u062a \\u0628\\u06cc\\u0634\\u062a\\u0631\",\"questionAnswer\":\"\\u067e\\u0631\\u062a\\u0644\\u0627\\u0634 \\u0648 \\u06a9\\u0648\\u0634\\u0627\",\"questionAnswerCheckbox\":[\"\"]}]', '2016-10-21 18:01:20', '2016-10-21 18:01:20'),
(7, 1, 'فرم استخدام', '[{\"questionType\":\"Text\",\"questionText\":\"\\u0646\\u0627\\u0645\",\"questionAnswer\":\"\\u062d\\u06a9\\u06cc\\u062f\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"Text\",\"questionText\":\"\\u0646\\u0627\\u0645 \\u062e\\u0627\\u0646\\u0648\\u0627\\u062f\\u06af\\u06cc\",\"questionAnswer\":\"\\u0641\\u0631\\u062e\\u06cc\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0648\\u0636\\u0639\\u06cc\\u062a \\u0633\\u0631\\u0628\\u0627\\u0632\\u06cc\",\"questionItems\":[\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u06a9\\u0641\\u0627\\u0644\\u062a\",\"\\u06a9\\u0627\\u0631\\u062a \\u067e\\u0627\\u06cc\\u0627\\u0646 \\u062e\\u062f\\u0645\\u062a\",\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u067e\\u0632\\u0634\\u06a9\\u06cc\"],\"questionAnswer\":\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u067e\\u0632\\u0634\\u06a9\\u06cc\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiCheckbox\",\"questionText\":\"\\u062a\\u062e\\u0635\\u0635 \\u0647\\u0627\",\"questionItems\":[\"\\u0637\\u0631\\u0627\\u062d\\u06cc \\u0648\\u0628\",\"\\u0628\\u0631\\u0646\\u0627\\u0645\\u0647 \\u0646\\u0648\\u06cc\\u0633\\u06cc PHP\",\"\\u062c\\u0627\\u0648\\u0627\",\"\\u0644\\u06cc\\u0646\\u0648\\u06a9\\u0633\",\"\\u0634\\u0628\\u06a9\\u0647\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\",\"\\u0644\\u06cc\\u0646\\u0648\\u06a9\\u0633\",\"\\u062c\\u0627\\u0648\\u0627\"]},{\"questionType\":\"TextLarge\",\"questionText\":\"\\u062a\\u0648\\u0636\\u06cc\\u062d\\u0627\\u062a \\u0628\\u06cc\\u0634\\u062a\\u0631\",\"questionAnswer\":\"\\u062f\\u0627\\u0631\\u0627\\u06cc \\u0645\\u062f\\u0631\\u06a9 \\u062f\\u06a9\\u062a\\u0631\\u06cc \\u0627\\u0632 \\u062f\\u0627\\u0646\\u0634\\u06af\\u0627\\u0647 \\u062a\\u0647\\u0631\\u0627\\u0646\",\"questionAnswerCheckbox\":[\"\"]}]', '2016-10-21 18:05:01', '2016-10-21 18:05:01'),
(8, 3, 'بیبسیبیسبس', '[{\"questionType\":\"Text\",\"questionText\":\"\\u0642\\u0642\\u0644\\u06cc\\u0644\\u0627\\u06cc\\u0644\",\"questionAnswer\":\"\\u0642\\u0641\\u0641\\u0639\\u0642\\u0641\\u0642\\u0641\\u063a\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"TextLarge\",\"questionText\":\"\\u0633\\u062b\\u0641\\u0635\\u062b\\u0641\\u062b\\u0635\",\"questionAnswer\":\"\\u0642\\u0641\\u063a\\u0642\\u0641\\u063a\\u0642\\u0641\\u063a\\u0642\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0628\\u0644\\u06cc\\u0628\\u0644\\u06cc\\u0644\\u06cc\",\"questionItems\":[\"\\u0627\\u06cc\\u0628\\u0644\",\"\\u06cc\\u0628\\u0644\",\"\",\"\"],\"questionAnswer\":\"\\u06cc\\u0628\\u0644\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiCheckbox\",\"questionText\":\"\\u0644\\u0627\\u062a\\u0644\\u0627\\u062a\\u0644\\u0627\\u062a\\u0644\\u0627\",\"questionItems\":[\"\\u062a\\u0644\\u0627\\u062a\\u0644\\u0627\\u062a\\u0644\",\"\\u062a\\u0644\\u0627\\u062a\\u0644\",\"\\u0644\\u0627\\u062a\\u0644\\u0627\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\",\"\\u062a\\u0644\\u0627\\u062a\\u0644\"]}]', '2016-10-22 14:42:19', '2016-10-22 14:42:19'),
(9, 1, 'فرم استخدام', '[{\"questionType\":\"Text\",\"questionText\":\"\\u0646\\u0627\\u0645\",\"questionAnswer\":\"\\u06cc\\u06cc\\u0642\\u0644\\u06cc\\u0642\\u0644\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"Text\",\"questionText\":\"\\u0646\\u0627\\u0645 \\u062e\\u0627\\u0646\\u0648\\u0627\\u062f\\u06af\\u06cc\",\"questionAnswer\":\"\\u0642\\u0644\\u06cc\\u0642\\u0642\\u06cc\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0648\\u0636\\u0639\\u06cc\\u062a \\u0633\\u0631\\u0628\\u0627\\u0632\\u06cc\",\"questionItems\":[\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u06a9\\u0641\\u0627\\u0644\\u062a\",\"\\u06a9\\u0627\\u0631\\u062a \\u067e\\u0627\\u06cc\\u0627\\u0646 \\u062e\\u062f\\u0645\\u062a\",\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u067e\\u0632\\u0634\\u06a9\\u06cc\"],\"questionAnswer\":\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u06a9\\u0641\\u0627\\u0644\\u062a\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiCheckbox\",\"questionText\":\"\\u062a\\u062e\\u0635\\u0635 \\u0647\\u0627\",\"questionItems\":[\"\\u0637\\u0631\\u0627\\u062d\\u06cc \\u0648\\u0628\",\"\\u0628\\u0631\\u0646\\u0627\\u0645\\u0647 \\u0646\\u0648\\u06cc\\u0633\\u06cc PHP\",\"\\u062c\\u0627\\u0648\\u0627\",\"\\u0644\\u06cc\\u0646\\u0648\\u06a9\\u0633\",\"\\u0634\\u0628\\u06a9\\u0647\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\",\"\\u0637\\u0631\\u0627\\u062d\\u06cc \\u0648\\u0628\",\"\\u062c\\u0627\\u0648\\u0627\"]},{\"questionType\":\"TextLarge\",\"questionText\":\"\\u062a\\u0648\\u0636\\u06cc\\u062d\\u0627\\u062a \\u0628\\u06cc\\u0634\\u062a\\u0631\",\"questionAnswer\":\"\\u0632\\u0628\\u0627\\u0628\\u06cc\\u0644\\u06cc\",\"questionAnswerCheckbox\":[\"\"]}]', '2016-10-22 14:43:02', '2016-10-22 14:43:02');

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

CREATE TABLE `forms` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `questions` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `forms`
--

INSERT INTO `forms` (`id`, `title`, `questions`, `created_at`, `updated_at`) VALUES
(1, 'فرم استخدام', '[{\"questionType\":\"Text\",\"questionText\":\"\\u0646\\u0627\\u0645\",\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"Text\",\"questionText\":\"\\u0646\\u0627\\u0645 \\u062e\\u0627\\u0646\\u0648\\u0627\\u062f\\u06af\\u06cc\",\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0648\\u0636\\u0639\\u06cc\\u062a \\u0633\\u0631\\u0628\\u0627\\u0632\\u06cc\",\"questionItems\":[\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u06a9\\u0641\\u0627\\u0644\\u062a\",\"\\u06a9\\u0627\\u0631\\u062a \\u067e\\u0627\\u06cc\\u0627\\u0646 \\u062e\\u062f\\u0645\\u062a\",\"\\u0645\\u0639\\u0627\\u0641\\u06cc\\u062a \\u067e\\u0632\\u0634\\u06a9\\u06cc\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiCheckbox\",\"questionText\":\"\\u062a\\u062e\\u0635\\u0635 \\u0647\\u0627\",\"questionItems\":[\"\\u0637\\u0631\\u0627\\u062d\\u06cc \\u0648\\u0628\",\"\\u0628\\u0631\\u0646\\u0627\\u0645\\u0647 \\u0646\\u0648\\u06cc\\u0633\\u06cc PHP\",\"\\u062c\\u0627\\u0648\\u0627\",\"\\u0644\\u06cc\\u0646\\u0648\\u06a9\\u0633\",\"\\u0634\\u0628\\u06a9\\u0647\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"TextLarge\",\"questionText\":\"\\u062a\\u0648\\u0636\\u06cc\\u062d\\u0627\\u062a \\u0628\\u06cc\\u0634\\u062a\\u0631\",\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]}]', '2016-10-21 17:53:26', '2016-10-21 17:53:26'),
(2, 'فرم نظرسنجی', '[{\"questionType\":\"MultiOption\",\"questionText\":\"\\u06a9\\u06cc\\u0641\\u06cc\\u062a \\u063a\\u0630\\u0627\",\"questionItems\":[\"\\u062e\\u0648\\u0628\",\"\\u0645\\u062a\\u0648\\u0633\\u0637\",\"\\u0628\\u062f\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0632\\u0645\\u0627\\u0646 \\u0622\\u0645\\u0627\\u062f\\u0647 \\u0633\\u0627\\u0632\\u06cc \\u063a\\u0630\\u0627\",\"questionItems\":[\"\\u062e\\u0648\\u0628 \",\"\\u0645\\u062a\\u0648\\u0633\\u0637\",\"\\u0628\\u062f\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0628\\u0631\\u062e\\u0648\\u0631\\u062f \\u06a9\\u0627\\u0631\\u06a9\\u0646\\u0627\\u0646\",\"questionItems\":[\"\\u062e\\u0648\\u0628\",\"\\u0645\\u062a\\u0648\\u0633\\u0637\",\"\\u0628\\u062f\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiCheckbox\",\"questionText\":\"\\u0648\\u06cc\\u0698\\u06af\\u06cc \\u0647\\u0627\\u06cc \\u0628\\u0627\\u0631\\u0632 \\u0648 \\u0645\\u062b\\u0628\\u062a \\u0627\\u0632 \\u0646\\u0638\\u0631 \\u0634\\u0645\\u0627\",\"questionItems\":[\"\\u0645\\u0646\\u0638\\u0631\\u0647 \\u0628\\u06cc\\u0631\\u0648\\u0646\\u06cc\",\"\\u0622\\u0647\\u0646\\u06af \\u067e\\u062e\\u0634 \\u0634\\u062f\\u0647\",\"\\u0646\\u0645\\u0627\\u06cc \\u062f\\u0627\\u062e\\u0644\\u06cc\",\"\\u062a\\u0646\\u0648\\u0639 \\u063a\\u0630\\u0627 \\u0647\\u0627\",\"\\u0628\\u0631\\u062e\\u0648\\u0631\\u062f \\u06a9\\u0627\\u0631\\u06a9\\u0646\\u0627\\u0646\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"TextLarge\",\"questionText\":\"\\u0646\\u0638\\u0631\\u0627\\u062a \\u0648 \\u067e\\u06cc\\u0634\\u0646\\u0647\\u0627\\u062f\\u0627\\u062a \\u062f\\u06cc\\u06af\\u0631\",\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]}]', '2016-10-21 17:59:41', '2016-10-21 17:59:41'),
(3, 'بیبسیبیسبس', '[{\"questionType\":\"Text\",\"questionText\":\"\\u0642\\u0642\\u0644\\u06cc\\u0644\\u0627\\u06cc\\u0644\",\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiOption\",\"questionText\":\"\\u0628\\u0644\\u06cc\\u0628\\u0644\\u06cc\\u0644\\u06cc\",\"questionItems\":[\"\\u0627\\u06cc\\u0628\\u0644\",\"\\u06cc\\u0628\\u0644\",\"\",\"\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]},{\"questionType\":\"MultiCheckbox\",\"questionText\":\"\\u0644\\u0627\\u062a\\u0644\\u0627\\u062a\\u0644\\u0627\\u062a\\u0644\\u0627\",\"questionItems\":[\"\\u062a\\u0644\\u0627\\u062a\\u0644\\u0627\\u062a\\u0644\",\"\\u0644\\u0627\\u062a\\u0644\\u0627\"],\"questionAnswer\":\"\",\"questionAnswerCheckbox\":[\"\"]}]', '2016-10-22 14:41:55', '2016-10-22 14:43:20');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2017_05_05_103311_create_forms_table', 1),
('2017_05_09_103311_create_filled_forms_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `filled_forms`
--
ALTER TABLE `filled_forms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `filled_forms_id_unique` (`id`),
  ADD KEY `filled_forms_form_id_foreign` (`form_id`);

--
-- Indexes for table `forms`
--
ALTER TABLE `forms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `forms_id_unique` (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `filled_forms`
--
ALTER TABLE `filled_forms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `forms`
--
ALTER TABLE `forms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `filled_forms`
--
ALTER TABLE `filled_forms`
  ADD CONSTRAINT `filled_forms_form_id_foreign` FOREIGN KEY (`form_id`) REFERENCES `forms` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
